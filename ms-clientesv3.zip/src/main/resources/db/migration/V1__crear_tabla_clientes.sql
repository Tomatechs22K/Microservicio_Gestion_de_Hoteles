CREATE TABLE clientes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT(20) NOT NULL UNIQUE,
    hotel_id INT(20) NOT NULL,
    comienzo_estancia DATE,
    fin_estancia DATE,
);

-- Insertar datos iniciales para probar
INSERT INTO clientes (usuario_id, hotel_id, comienzo_estancia, fin_estancia)
VALUES (1, 1, "01/01/2026", "31/05/2026");