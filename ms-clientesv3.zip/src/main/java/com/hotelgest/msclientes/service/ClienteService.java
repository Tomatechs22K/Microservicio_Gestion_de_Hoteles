package com.hotelgest.msclientes.service;

import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// @RequiredArgsConstructor → inyección por constructor de todos los final.
// @Service     → marca esta clase como componente de capa de negocio.
@Service
@RequiredArgsConstructor
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public List<Cliente> obtenerTodas() {
        return clienteRepository.findAll();
    }

    public List<Cliente> buscarPorUsuario(Integer user_id) {
        return clienteRepository.buscarPorUsuario(user_id);
    }

    public List<Cliente> buscarPorHotel(Integer hotel_id) {
        return clienteRepository.buscarPorHotel(hotel_id);
    }

    public Optional<Cliente> obtenerPorId(Long id) {
        return clienteRepository.findById(id);
    }

    public Cliente guardar(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public Optional<Cliente> actualizar(Long id, Cliente datos) {
        return clienteRepository.findById(id).map(e -> {
            e.setHotel_id(datos.getHotel_id());
            e.setUsuario_id(datos.getUsuario_id());
            e.setComienzo_estancia(datos.getComienzo_estancia());
            e.setFin_estancia(datos.getFin_estancia());
            return clienteRepository.save(e);
        });
    }

    public void eliminar(Long id) {
        clienteRepository.deleteById(id);
    }
}
