package com.hotelgest.msclientes.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

// ═══════════════════════════════════════════════════
// @Entity  → Hibernate registra esta clase como entidad JPA.
//            Crea/actualiza la tabla 'hoteles' al arrancar.
// @Table   → nombre explícito de la tabla en MySQL.
// @Data    → Lombok genera getters, setters, equals, toString.
// ═══════════════════════════════════════════════════
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientes")
public class Cliente {

    // @Id + IDENTITY → clave primaria AUTO_INCREMENT en MySQL
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El usuario no puede estar vacío")
    @Size(max = 20, message = "Máximo 20 caracteres")
    @Column(nullable = false, unique = true, length = 20)
    private Integer usuario_id;

    @NotBlank(message = "El hotel no puede estar vacío")
    @Size(max = 20, message = "Máximo 20 caracteres")
    @Column(nullable = false, length = 20)
    private Integer hotel_id;

    @Column(nullable = false)
    private Date comienzo_estancia;

    @Column(nullable = false)
    private Date fin_estancia;
}