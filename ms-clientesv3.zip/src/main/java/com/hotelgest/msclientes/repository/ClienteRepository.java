package com.hotelgest.msclientes.repository;

import com.hotelgest.msclientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

// ═══════════════════════════════════════════════════
// JpaRepository<Hotel, Long> nos da gratis:
//   findAll(), findById(), save(), deleteById(), count()…
//
// @Query usa JPQL: se escribe sobre CLASES y ATRIBUTOS Java,
// NO sobre tablas y columnas SQL.
// ═══════════════════════════════════════════════════
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // LOWER() en ambos lados → búsqueda case-insensitive
    // CONCAT('%', :nombre, '%') → patrón LIKE dinámico
    @Query("SELECT e FROM Clientes e WHERE LOWER(e.hotel_id) LIKE LOWER(CONCAT('%', :hotel_id, '%'))")
    List<Cliente> buscarPorHotel(@Param("hotel_id") Integer hotel_id);

    @Query("SELECT e FROM Clientes e WHERE LOWER(e.user_id) LIKE LOWER(CONCAT('%', :user_id, '%'))")
    List<Cliente> buscarPorUsuario(@Param("user_id") Integer user_id);
}
