package com.hotelgest.msclientes.controller;

import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.service.ClienteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// @RestController = @Controller + @ResponseBody
// @RequestMapping → prefijo base para todos los endpoints
@RestController
@RequestMapping("/api/hoteles")
@RequiredArgsConstructor
public class ClienteController {

    private final ClienteService clienteService;

    // GET /api/hoteles → todas
    @GetMapping
    public List<Cliente> obtenerTodas() {
        return clienteService.obtenerTodas();
    }

    @GetMapping("/user")
    public List<Cliente> buscarUsuario(@RequestParam Integer user_id) {
        return clienteService.buscarPorUsuario(user_id);
    }

    @GetMapping("/hotel")
    public List<Cliente> buscarHotel(@RequestParam Integer hotel_id) {
        return clienteService.buscarPorHotel(hotel_id);
    }

    // GET /api/hoteles/{id}
    // ResponseEntity permite devolver 200 con body o 404 vacío
    @GetMapping("/{id}")
    public ResponseEntity<Cliente> obtenerPorId(@PathVariable Long id) {
        return clienteService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /api/hoteles → @Valid activa las validaciones del modelo
    @PostMapping
    public ResponseEntity<Cliente> crear(@Valid @RequestBody Cliente cliente) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(clienteService.guardar(cliente));
    }

    // PUT /api/hoteles/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Cliente> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody Cliente datos) {
        return clienteService.actualizar(id, datos)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE /api/hoteles/{id} → 204 No Content
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        clienteService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
