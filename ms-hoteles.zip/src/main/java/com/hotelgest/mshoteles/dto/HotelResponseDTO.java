package com.hotelgest.mshoteles.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class HotelResponseDTO {
    private Long id;
    private String nombre;
    private String direccion;
    private int estrellas;
}
