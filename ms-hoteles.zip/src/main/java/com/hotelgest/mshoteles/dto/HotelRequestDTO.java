package com.hotelgest.mshoteles.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class HotelRequestDTO {

    @NotBlank(message = "El nombre no puede estar vacío")
    @Size(max = 100, message = "Máximo 100 caracteres")
    private String nombre;

    @NotBlank(message = "La direccion no puede estar vacía")
    @Size(max = 300, message = "Máximo 300 caracteres")
    private String direccion;
    
    @Min(value = 0, message = "Las estrellas no pueden ser menores a 0")
    @Max(value = 5, message = "El máximo de estrellas es 5")
    private int estrellas;
}