package com.hotelgest.mshoteles.controller;

import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.service.HotelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// @RestController = @Controller + @ResponseBody
// @RequestMapping → prefijo base para todos los endpoints
@RestController
@RequestMapping("/api/hoteles")
@RequiredArgsConstructor
public class HotelController {

    private final HotelService hotelService;

    @GetMapping
    public ResponseEntity<List<HotelResponseDTO>> obtenerTodos() {
        return ResponseEntity.ok(hotelService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> obtenerPorId(@PathVariable Long id) {
        return hotelService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<HotelResponseDTO> crear(
            @Valid @RequestBody HotelRequestDTO dto) {
        return ResponseEntity.status(201).body(hotelService.guardar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> actualizar(
            @PathVariable Long id, @Valid @RequestBody HotelRequestDTO dto) {
        return hotelService.actualizar(id, dto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (hotelService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        hotelService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
