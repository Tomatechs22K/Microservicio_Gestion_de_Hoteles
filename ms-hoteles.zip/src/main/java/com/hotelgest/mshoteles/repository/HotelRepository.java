package com.hotelgest.mshoteles.repository;

import com.hotelgest.mshoteles.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

// ═══════════════════════════════════════════════════
// JpaRepository<Especialidad, Long> nos da gratis:
//   findAll(), findById(), save(), deleteById(), count()…
//
// @Query usa JPQL: se escribe sobre CLASES y ATRIBUTOS Java,
// NO sobre tablas y columnas SQL.
// ═══════════════════════════════════════════════════
public interface HotelRepository extends JpaRepository<Hotel, Long> {

    // SQL generado: SELECT * FROM hoteles WHERE activa = 1
    @Query("SELECT h FROM Hotel h WHERE h.activo = true")
    List<Hotel> findAllActivas();

    // LOWER() en ambos lados → búsqueda case-insensitive
    // CONCAT('%', :nombre, '%') → patrón LIKE dinámico
    @Query("SELECT h FROM Hotel h WHERE LOWER(h.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    List<Hotel> buscarPorNombre(@Param("nombre") String nombre);
}