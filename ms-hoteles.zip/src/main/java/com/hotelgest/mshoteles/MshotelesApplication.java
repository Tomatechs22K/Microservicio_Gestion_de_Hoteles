package com.hotelgest.mshoteles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MshotelesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MshotelesApplication.class, args);
	}

}
