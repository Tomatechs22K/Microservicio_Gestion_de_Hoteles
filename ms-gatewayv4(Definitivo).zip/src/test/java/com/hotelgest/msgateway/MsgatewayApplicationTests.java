package com.hotelgest.msgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
