package com.hotelgest.mshoteles.controller;

import com.hotelgest.mshoteles.assemblers.HotelModelAssembler;
import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.service.HotelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/hoteles")
@RequiredArgsConstructor
@Tag(name = "Hoteles V2", description = "Operaciones CRUD con HATEOAS")
public class HotelControllerV2 {

    private final HotelService hotelService;
    private final HotelModelAssembler assembler;

    @Operation(summary = "Obtener todos los hoteles con HATEOAS")
    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<HotelResponseDTO>> obtenerTodos() {
        List<EntityModel<HotelResponseDTO>> hoteles = hotelService.obtenerTodos()
                .stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(hoteles,
                linkTo(methodOn(HotelControllerV2.class).obtenerTodos()).withSelfRel());
    }

    @Operation(summary = "Obtener hotel por ID con HATEOAS")
    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HotelResponseDTO>> obtenerPorId(@PathVariable Long id) {
        return hotelService.obtenerPorId(id)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear hotel con HATEOAS")
    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HotelResponseDTO>> crear(@Valid @RequestBody HotelRequestDTO dto) {
        HotelResponseDTO creado = hotelService.guardar(dto);
        return ResponseEntity.status(201).body(assembler.toModel(creado));
    }

    @Operation(summary = "Actualizar hotel con HATEOAS")
    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HotelResponseDTO>> actualizar(
            @PathVariable Long id, @Valid @RequestBody HotelRequestDTO dto) {
        return hotelService.actualizar(id, dto)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar hotel con HATEOAS")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (hotelService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        hotelService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}