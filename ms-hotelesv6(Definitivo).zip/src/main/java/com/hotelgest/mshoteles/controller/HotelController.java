package com.hotelgest.mshoteles.controller;

import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.service.HotelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hoteles")
@RequiredArgsConstructor
@Tag(name = "Hoteles", description = "Operaciones CRUD para la gestión de hoteles")
public class HotelController {

    private final HotelService hotelService;

    @Operation(summary = "Obtener todos los hoteles")
    @ApiResponse(responseCode = "200", description = "Lista de hoteles retornada exitosamente")
    @GetMapping
    public ResponseEntity<List<HotelResponseDTO>> obtenerTodos() {
        return ResponseEntity.ok(hotelService.obtenerTodos());
    }

    @Operation(summary = "Obtener hotel por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Hotel encontrado"),
            @ApiResponse(responseCode = "404", description = "Hotel no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> obtenerPorId(@PathVariable Long id) {
        return hotelService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear un nuevo hotel")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Hotel creado exitosamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos en la solicitud")
    })
    @PostMapping
    public ResponseEntity<HotelResponseDTO> crear(@Valid @RequestBody HotelRequestDTO dto) {
        return ResponseEntity.status(201).body(hotelService.guardar(dto));
    }

    @Operation(summary = "Actualizar un hotel existente")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Hotel actualizado exitosamente"),
            @ApiResponse(responseCode = "404", description = "Hotel no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> actualizar(
            @PathVariable Long id, @Valid @RequestBody HotelRequestDTO dto) {
        return hotelService.actualizar(id, dto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar un hotel por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Hotel eliminado exitosamente"),
            @ApiResponse(responseCode = "404", description = "Hotel no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (hotelService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        hotelService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Obtener habitaciones de un hotel")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Habitaciones retornadas exitosamente"),
            @ApiResponse(responseCode = "404", description = "Hotel no encontrado")
    })
    @GetMapping("/{id}/habitaciones")
    public ResponseEntity<?> obtenerHabitaciones(@PathVariable Long id) {
        if (hotelService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(hotelService.obtenerHabitacionesDeHotel(id));
    }
}