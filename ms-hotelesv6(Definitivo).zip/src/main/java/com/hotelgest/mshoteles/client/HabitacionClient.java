package com.hotelgest.mshoteles.client;

import com.hotelgest.mshoteles.dto.HabitacionResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "ms-habitaciones", url = "${ms.habitaciones.url}")
public interface HabitacionClient {

    @GetMapping("/api/habitaciones/hotel/{hotelId}")
    List<HabitacionResponseDTO> obtenerHabitacionesPorHotel(@PathVariable Long hotelId);
}