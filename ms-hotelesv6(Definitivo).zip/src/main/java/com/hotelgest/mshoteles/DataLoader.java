package com.hotelgest.mshoteles;

import com.hotelgest.mshoteles.model.Hotel;
import com.hotelgest.mshoteles.repository.HotelRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Random;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        // Generar hoteles
        for (int i = 0; i < 10; i++) {
            Hotel hotel = new Hotel();
            hotel.setNombre(faker.company().name() + " Hotel");
            hotel.setDireccion(faker.address().streetAddress() + ", " + faker.address().city());
            hotel.setEstrellas(faker.number().numberBetween(1, 5));
            hotel.setActivo(true);
            hotelRepository.save(hotel);
        }
    }
}