package com.hotelgest.mshoteles.assemblers;

import com.hotelgest.mshoteles.controller.HotelController;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class HotelModelAssembler implements RepresentationModelAssembler<HotelResponseDTO, EntityModel<HotelResponseDTO>> {

    @Override
    public EntityModel<HotelResponseDTO> toModel(HotelResponseDTO hotel) {
        return EntityModel.of(hotel,
                linkTo(methodOn(HotelController.class).obtenerPorId(hotel.getId())).withSelfRel(),
                linkTo(methodOn(HotelController.class).obtenerTodos()).withRel("hoteles"),
                linkTo(methodOn(HotelController.class).obtenerHabitaciones(hotel.getId())).withRel("habitaciones")
        );
    }
}