package com.hotelgest.mshoteles.service;

import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.client.HabitacionClient;
import com.hotelgest.mshoteles.dto.HabitacionResponseDTO;
import com.hotelgest.mshoteles.model.Hotel;
import com.hotelgest.mshoteles.repository.HotelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

// @RequiredArgsConstructor → inyección por constructor de todos los final.
// @Service     → marca esta clase como componente de capa de negocio.
@Service
@RequiredArgsConstructor
public class HotelService {

    private final HotelRepository hotelRepository;
    private final HabitacionClient habitacionClient;

    private HotelResponseDTO mapToDTO(Hotel h) {
        return new HotelResponseDTO(h.getId(), h.getNombre(),
                h.getDireccion(), h.getEstrellas());
    }

    public List<HotelResponseDTO> obtenerTodos() {
        return hotelRepository.findAll().stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<HotelResponseDTO> obtenerPorId(Long id) {
        return hotelRepository.findById(id).map(this::mapToDTO);
    }

    public HotelResponseDTO guardar(HotelRequestDTO dto) {
        Hotel hotel = new Hotel(null, dto.getNombre(), dto.getDireccion(), dto.getEstrellas(), true);
        return mapToDTO(hotelRepository.save(hotel));
    }

    public Optional<HotelResponseDTO> actualizar(Long id, HotelRequestDTO dto) {
        return hotelRepository.findById(id).map(existente -> {
            existente.setNombre(dto.getNombre());
            existente.setDireccion(dto.getDireccion());
            existente.setEstrellas(dto.getEstrellas());
            return mapToDTO(hotelRepository.save(existente));
        });
    }

    public void eliminar(Long id) {
        hotelRepository.deleteById(id);
    }

    public List<HabitacionResponseDTO> obtenerHabitacionesDeHotel(Long hotelId) {
        return habitacionClient.obtenerHabitacionesPorHotel(hotelId);
    }
}
