package com.hotelgest.mshoteles.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HabitacionResponseDTO {
    private Long id;
    private Long hotelId;
    private String numero;
    private String tipo;
    private BigDecimal precioNoche;
    private boolean disponible;
}