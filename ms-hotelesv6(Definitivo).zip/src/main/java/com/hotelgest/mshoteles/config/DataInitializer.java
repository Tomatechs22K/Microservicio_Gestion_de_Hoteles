package com.hotelgest.mshoteles.config;

import com.hotelgest.mshoteles.model.Hotel;
import com.hotelgest.mshoteles.repository.HotelRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("dev")
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final HotelRepository repository;

    @Override
    public void run(String... args){
        if (repository.count()>0){
            log.info(">>> HOTELES YA CARGADOS, SE OMITE INICIALIZACIÓN");
            return;
        }
        log.info(">>> CARGANDO HOTELES INICIALES");
        repository.save(new Hotel(null, "Hilton Buenos Aires", "Macacha Güemes 351, C1106BKG Cdad. Autónoma de Buenos Aires, Argentina", 5, true));
        repository.save(new Hotel(null, "Hotel Plaza Revolución", "Terán 15, Tabacalera, Cuauhtémoc, CDMX, México", 4, true));
        repository.save(new Hotel(null, "Hotel España", "C/ de Sant Pau, 9-11, Ciutat Vella, Barcelona, España", 4, true));
        repository.save(new Hotel(null, "Hotel MX más centro CDMX", "República de Uruguay 90, Centro Histórico, Cuauhtémoc, 06060 CDMX, México", 3, true));
        repository.save(new Hotel(null, "Hotel Moderno", "C. del Arenal, 2, Centro, 28013 Madrid, España", 3, true));
        repository.save(new Hotel(null, "Gran Hotel Argentino", "Carlos Pellegrini 37, C1009ABA Cdad. Autónoma de Buenos Aires, Argentina", 3, true));
        repository.save(new Hotel(null, "Hotel Estrella de Oriente", "Calzada Ignacio Zaragoza #1013, 15000 CDMX, México", 2, true));
        log.info(">>> 7 hoteles cargados...");
    }
}