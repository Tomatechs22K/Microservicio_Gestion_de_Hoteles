package com.hotelgest.mshoteles.service;

import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.model.Hotel;
import com.hotelgest.mshoteles.repository.HotelRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
public class HotelServiceTest {

    @Autowired
    private HotelService hotelService;

    @MockitoBean
    private HotelRepository hotelRepository;

    // ─── Helper ───────────────────────────────────────────
    private Hotel crearHotel() {
        return new Hotel(1L, "Hilton Santiago", "Av. Siempreviva 123", 5, true);
    }

    // ─── obtenerTodos ──────────────────────────────────────
    @Test
    public void testObtenerTodos() {
        when(hotelRepository.findAll()).thenReturn(List.of(crearHotel()));

        List<HotelResponseDTO> resultado = hotelService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Hilton Santiago", resultado.get(0).getNombre());
    }

    // ─── obtenerPorId (encontrado) ─────────────────────────
    @Test
    public void testObtenerPorId_encontrado() {
        when(hotelRepository.findById(1L)).thenReturn(Optional.of(crearHotel()));

        Optional<HotelResponseDTO> resultado = hotelService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(1L, resultado.get().getId());
        assertEquals("Hilton Santiago", resultado.get().getNombre());
    }

    // ─── obtenerPorId (no encontrado) ──────────────────────
    @Test
    public void testObtenerPorId_noEncontrado() {
        when(hotelRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<HotelResponseDTO> resultado = hotelService.obtenerPorId(99L);

        assertFalse(resultado.isPresent());
    }

    // ─── guardar ───────────────────────────────────────────
    @Test
    public void testGuardar() {
        Hotel hotelGuardado = crearHotel();
        when(hotelRepository.save(any(Hotel.class))).thenReturn(hotelGuardado);

        HotelRequestDTO dto = new HotelRequestDTO("Hilton Santiago", "Av. Siempreviva 123", 5);
        HotelResponseDTO resultado = hotelService.guardar(dto);

        assertNotNull(resultado);
        assertEquals("Hilton Santiago", resultado.getNombre());
        assertEquals(5, resultado.getEstrellas());
    }

    // ─── actualizar (encontrado) ───────────────────────────
    @Test
    public void testActualizar_encontrado() {
        Hotel hotelExistente = crearHotel();
        when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotelExistente));
        when(hotelRepository.save(any(Hotel.class))).thenReturn(hotelExistente);

        HotelRequestDTO dto = new HotelRequestDTO("Hilton Actualizado", "Nueva Dirección 456", 4);
        Optional<HotelResponseDTO> resultado = hotelService.actualizar(1L, dto);

        assertTrue(resultado.isPresent());
        assertEquals("Hilton Actualizado", resultado.get().getNombre());
        assertEquals(4, resultado.get().getEstrellas());
    }

    // ─── actualizar (no encontrado) ────────────────────────
    @Test
    public void testActualizar_noEncontrado() {
        when(hotelRepository.findById(99L)).thenReturn(Optional.empty());

        HotelRequestDTO dto = new HotelRequestDTO("X", "Y", 1);
        Optional<HotelResponseDTO> resultado = hotelService.actualizar(99L, dto);

        assertFalse(resultado.isPresent());
    }

    // ─── eliminar ──────────────────────────────────────────
    @Test
    public void testEliminar() {
        doNothing().when(hotelRepository).deleteById(1L);

        hotelService.eliminar(1L);

        verify(hotelRepository, times(1)).deleteById(1L);
    }
}