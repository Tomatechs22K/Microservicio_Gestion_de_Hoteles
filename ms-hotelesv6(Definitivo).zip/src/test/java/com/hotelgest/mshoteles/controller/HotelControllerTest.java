package com.hotelgest.mshoteles.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotelgest.mshoteles.dto.HotelRequestDTO;
import com.hotelgest.mshoteles.dto.HotelResponseDTO;
import com.hotelgest.mshoteles.service.HotelService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(HotelController.class)
public class HotelControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private HotelService hotelService;

    @Autowired
    private ObjectMapper objectMapper;

    private HotelResponseDTO responseDTO;
    private HotelRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        responseDTO = new HotelResponseDTO(1L, "Hilton Santiago", "Av. Siempreviva 123", 5);
        requestDTO  = new HotelRequestDTO("Hilton Santiago", "Av. Siempreviva 123", 5);
    }

    @Test
    public void testObtenerTodos() throws Exception {
        when(hotelService.obtenerTodos()).thenReturn(List.of(responseDTO));

        mockMvc.perform(get("/api/hoteles"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Hilton Santiago"));
    }

    @Test
    public void testObtenerPorId_encontrado() throws Exception {
        when(hotelService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));

        mockMvc.perform(get("/api/hoteles/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre").value("Hilton Santiago"));
    }

    @Test
    public void testObtenerPorId_noEncontrado() throws Exception {
        when(hotelService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/hoteles/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testCrear() throws Exception {
        when(hotelService.guardar(any(HotelRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/api/hoteles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre").value("Hilton Santiago"));
    }

    @Test
    public void testActualizar_encontrado() throws Exception {
        when(hotelService.actualizar(eq(1L), any(HotelRequestDTO.class)))
                .thenReturn(Optional.of(responseDTO));

        mockMvc.perform(put("/api/hoteles/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Hilton Santiago"));
    }

    @Test
    public void testActualizar_noEncontrado() throws Exception {
        when(hotelService.actualizar(eq(99L), any(HotelRequestDTO.class)))
                .thenReturn(Optional.empty());

        mockMvc.perform(put("/api/hoteles/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testEliminar_encontrado() throws Exception {
        when(hotelService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));
        doNothing().when(hotelService).eliminar(1L);

        mockMvc.perform(delete("/api/hoteles/1"))
                .andExpect(status().isNoContent());

        verify(hotelService, times(1)).eliminar(1L);
    }

    @Test
    public void testEliminar_noEncontrado() throws Exception {
        when(hotelService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/api/hoteles/99"))
                .andExpect(status().isNotFound());
    }
}