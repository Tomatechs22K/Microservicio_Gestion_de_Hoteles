package com.hotelgest.msusuarios.service;

import com.hotelgest.msusuarios.dto.UsuarioRequestDTO;
import com.hotelgest.msusuarios.dto.UsuarioResponseDTO;
import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class UsuarioServiceTest {

    @InjectMocks
    private UsuarioService usuarioService;

    @Mock
    private UsuarioRepository usuarioRepository;

    private Usuario crearUsuario() {
        return new Usuario(1L, "Juan Pérez", "Recepcionista", "+56912345678", true);
    }

    @Test
    public void testObtenerTodos() {
        when(usuarioRepository.findAllActivos()).thenReturn(List.of(crearUsuario()));

        List<UsuarioResponseDTO> resultado = usuarioService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Juan Pérez", resultado.get(0).getNombre());
    }

    @Test
    public void testObtenerPorId_encontrado() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(crearUsuario()));

        Optional<UsuarioResponseDTO> resultado = usuarioService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Recepcionista", resultado.get().getRol());
    }

    @Test
    public void testObtenerPorId_noEncontrado() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<UsuarioResponseDTO> resultado = usuarioService.obtenerPorId(99L);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testObtenerPorId_inactivo() {
        Usuario inactivo = crearUsuario();
        inactivo.setActivo(false);
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(inactivo));

        Optional<UsuarioResponseDTO> resultado = usuarioService.obtenerPorId(1L);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testBuscarPorNombre() {
        when(usuarioRepository.buscarPorNombre("Juan")).thenReturn(List.of(crearUsuario()));

        List<UsuarioResponseDTO> resultado = usuarioService.buscarPorNombre("Juan");

        assertEquals(1, resultado.size());
        assertEquals("Juan Pérez", resultado.get(0).getNombre());
    }

    @Test
    public void testGuardar() {
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(crearUsuario());

        UsuarioRequestDTO dto = new UsuarioRequestDTO("Juan Pérez", "Recepcionista", "+56912345678");
        UsuarioResponseDTO resultado = usuarioService.guardar(dto);

        assertNotNull(resultado);
        assertEquals("Juan Pérez", resultado.getNombre());
    }

    @Test
    public void testActualizar_encontrado() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(crearUsuario()));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(crearUsuario());

        UsuarioRequestDTO dto = new UsuarioRequestDTO("Juan Actualizado", "Gerente", "+56987654321");
        Optional<UsuarioResponseDTO> resultado = usuarioService.actualizar(1L, dto);

        assertTrue(resultado.isPresent());
    }

    @Test
    public void testActualizar_noEncontrado() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        UsuarioRequestDTO dto = new UsuarioRequestDTO("X", "Y", "Z");
        Optional<UsuarioResponseDTO> resultado = usuarioService.actualizar(99L, dto);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testEliminar() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(crearUsuario()));

        usuarioService.eliminar(1L);

        verify(usuarioRepository, times(1)).save(any(Usuario.class));
    }
}