package com.hotelgest.msusuarios;

import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.repository.UsuarioRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        String[] roles = {"Administrador", "Recepcionista", "Gerente", "Soporte"};

        for (int i = 0; i < 10; i++) {
            Usuario usuario = new Usuario();
            usuario.setNombre(faker.name().fullName());
            usuario.setRol(roles[faker.number().numberBetween(0, roles.length)]);
            usuario.setTelefono(faker.phoneNumber().phoneNumber());
            usuario.setActivo(true);
            usuarioRepository.save(usuario);
        }
    }
}