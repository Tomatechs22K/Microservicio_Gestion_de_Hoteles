package com.hotelgest.msusuarios.service;

import com.hotelgest.msusuarios.dto.UsuarioRequestDTO;
import com.hotelgest.msusuarios.dto.UsuarioResponseDTO;
import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    private UsuarioResponseDTO mapToDTO(Usuario u) {
        return new UsuarioResponseDTO(u.getId(), u.getNombre(),
                u.getRol(), u.getTelefono());
    }

    public List<UsuarioResponseDTO> obtenerTodos() {
        return usuarioRepository.findAllActivos().stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<UsuarioResponseDTO> obtenerPorId(Long id) {
        return usuarioRepository.findById(id)
                .filter(Usuario::isActivo)
                .map(this::mapToDTO);
    }

    public List<UsuarioResponseDTO> buscarPorNombre(String nombre) {
        return usuarioRepository.buscarPorNombre(nombre).stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public UsuarioResponseDTO guardar(UsuarioRequestDTO dto) {
        Usuario usuario = new Usuario(null, dto.getNombre(), dto.getRol(), dto.getTelefono(), true);
        return mapToDTO(usuarioRepository.save(usuario));
    }

    public Optional<UsuarioResponseDTO> actualizar(Long id, UsuarioRequestDTO dto) {
        return usuarioRepository.findById(id).map(existente -> {
            existente.setNombre(dto.getNombre());
            existente.setRol(dto.getRol());
            existente.setTelefono(dto.getTelefono());
            return mapToDTO(usuarioRepository.save(existente));
        });
    }

    public void eliminar(Long id) {
        usuarioRepository.findById(id).ifPresent(existente -> {
            existente.setActivo(false); // Eliminación lógica igual a ms-hoteles
            usuarioRepository.save(existente);
        });
    }
}
