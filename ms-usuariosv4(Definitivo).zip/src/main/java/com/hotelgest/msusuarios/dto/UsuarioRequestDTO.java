package com.hotelgest.msusuarios.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioRequestDTO {

        @NotBlank(message = "El nombre no puede estar vacío")
        @Size(max = 100, message = "Máximo 100 caracteres")
        private String nombre;

        @NotBlank(message = "El rol no puede estar vacío")
        @Size(max = 100, message = "Máximo 100 caracteres")
        private String rol;

        @Size(max = 20, message = "Máximo 20 caracteres")
        private String telefono;
}