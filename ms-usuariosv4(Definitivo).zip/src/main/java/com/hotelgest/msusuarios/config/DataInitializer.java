package com.hotelgest.msusuarios.config;

import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("dev")
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository repository;

    @Override
    public void run(String... args) {
        if (repository.count() > 0) {
            log.info(">>> USUARIOS YA CARGADOS, SE OMITE INICIALIZACIÓN");
            return;
        }
        log.info(">>> CARGANDO USUARIOS INICIALES");
        repository.save(new Usuario(null, "Esteban Quito", "Administrador", "+56911112222", true));
        repository.save(new Usuario(null, "Aquiles Baeza", "Recepcionista", "+56933334444", true));
        repository.save(new Usuario(null, "Elena Nito", "Supervisor", "+56955556666", true));
        repository.save(new Usuario(null, "Armando Casas", "Mantenimiento", "+56977778888", true));
    }
}