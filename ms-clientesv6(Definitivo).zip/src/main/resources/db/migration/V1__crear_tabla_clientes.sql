CREATE TABLE clientes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT NOT NULL,
    hotel_id BIGINT NOT NULL,
    comienzo_estancia DATE NOT NULL,
    fin_estancia DATE NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);