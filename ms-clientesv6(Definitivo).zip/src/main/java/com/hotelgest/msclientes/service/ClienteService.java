package com.hotelgest.msclientes.service;

import com.hotelgest.msclientes.dto.ClienteRequestDTO;
import com.hotelgest.msclientes.dto.ClienteResponseDTO;
import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ClienteService {

    private final ClienteRepository clienteRepository;

    private ClienteResponseDTO mapToDTO(Cliente c) {
        return new ClienteResponseDTO(c.getId(), c.getUsuarioId(),
                c.getHotelId(), c.getComienzoEstancia(), c.getFinEstancia());
    }

    public List<ClienteResponseDTO> obtenerTodos() {
        return clienteRepository.findAllActivos().stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<ClienteResponseDTO> obtenerPorId(Long id) {
        return clienteRepository.findById(id)
                .filter(Cliente::isActivo)
                .map(this::mapToDTO);
    }

    public List<ClienteResponseDTO> buscarPorUsuario(Long usuarioId) {
        return clienteRepository.buscarPorUsuario(usuarioId).stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public List<ClienteResponseDTO> buscarPorHotel(Long hotelId) {
        return clienteRepository.buscarPorHotel(hotelId).stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public ClienteResponseDTO guardar(ClienteRequestDTO dto) {
        Cliente cliente = new Cliente(null, dto.getUsuarioId(), dto.getHotelId(),
                dto.getComienzoEstancia(), dto.getFinEstancia(), true);
        return mapToDTO(clienteRepository.save(cliente));
    }

    public Optional<ClienteResponseDTO> actualizar(Long id, ClienteRequestDTO dto) {
        return clienteRepository.findById(id).map(existente -> {
            existente.setUsuarioId(dto.getUsuarioId());
            existente.setHotelId(dto.getHotelId());
            existente.setComienzoEstancia(dto.getComienzoEstancia());
            existente.setFinEstancia(dto.getFinEstancia());
            return mapToDTO(clienteRepository.save(existente));
        });
    }

    public void eliminar(Long id) {
        clienteRepository.findById(id).ifPresent(existente -> {
            existente.setActivo(false);
            clienteRepository.save(existente);
        });
    }
}