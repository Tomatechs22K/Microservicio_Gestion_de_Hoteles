package com.hotelgest.msclientes.controller;

import com.hotelgest.msclientes.dto.ClienteRequestDTO;
import com.hotelgest.msclientes.dto.ClienteResponseDTO;
import com.hotelgest.msclientes.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/clientes")
@RequiredArgsConstructor
@Tag(name = "Clientes", description = "Operaciones CRUD para la gestión de clientes")
public class ClienteController {

    private final ClienteService clienteService;

    @Operation(summary = "Obtener todos los clientes activos")
    @ApiResponse(responseCode = "200", description = "Lista retornada exitosamente")
    @GetMapping
    public ResponseEntity<CollectionModel<ClienteResponseDTO>> obtenerTodos() {
        List<ClienteResponseDTO> clientes = clienteService.obtenerTodos();
        clientes.forEach(c -> c.add(
                linkTo(methodOn(ClienteController.class).obtenerPorId(c.getId())).withSelfRel()
        ));
        return ResponseEntity.ok(CollectionModel.of(clientes,
                linkTo(methodOn(ClienteController.class).obtenerTodos()).withSelfRel()));
    }

    @Operation(summary = "Obtener cliente por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Cliente encontrado"),
            @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<ClienteResponseDTO> obtenerPorId(@PathVariable Long id) {
        return clienteService.obtenerPorId(id)
                .map(c -> {
                    c.add(
                            linkTo(methodOn(ClienteController.class).obtenerPorId(id)).withSelfRel(),
                            linkTo(methodOn(ClienteController.class).obtenerTodos()).withRel("todos")
                    );
                    return ResponseEntity.ok(c);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Buscar estancias por usuario")
    @ApiResponse(responseCode = "200", description = "Lista retornada exitosamente")
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<ClienteResponseDTO>> buscarPorUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(clienteService.buscarPorUsuario(usuarioId));
    }

    @Operation(summary = "Buscar estancias por hotel")
    @ApiResponse(responseCode = "200", description = "Lista retornada exitosamente")
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<ClienteResponseDTO>> buscarPorHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(clienteService.buscarPorHotel(hotelId));
    }

    @Operation(summary = "Crear un nuevo cliente")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Cliente creado exitosamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<ClienteResponseDTO> crear(@Valid @RequestBody ClienteRequestDTO dto) {
        ClienteResponseDTO creado = clienteService.guardar(dto);
        creado.add(linkTo(methodOn(ClienteController.class).obtenerPorId(creado.getId())).withSelfRel());
        return ResponseEntity.status(201).body(creado);
    }

    @Operation(summary = "Actualizar un cliente existente")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Cliente actualizado exitosamente"),
            @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<ClienteResponseDTO> actualizar(
            @PathVariable Long id, @Valid @RequestBody ClienteRequestDTO dto) {
        return clienteService.actualizar(id, dto)
                .map(c -> {
                    c.add(linkTo(methodOn(ClienteController.class).obtenerPorId(id)).withSelfRel());
                    return ResponseEntity.ok(c);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar (soft delete) un cliente")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Cliente eliminado exitosamente"),
            @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (clienteService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        clienteService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}