package com.hotelgest.msclientes.controller;

import com.hotelgest.msclientes.assemblers.ClienteModelAssembler;
import com.hotelgest.msclientes.dto.ClienteRequestDTO;
import com.hotelgest.msclientes.dto.ClienteResponseDTO;
import com.hotelgest.msclientes.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/clientes")
@RequiredArgsConstructor
@Tag(name = "Clientes V2", description = "Operaciones CRUD con HATEOAS")
public class ClienteControllerV2 {

    private final ClienteService clienteService;
    private final ClienteModelAssembler assembler;

    @Operation(summary = "Obtener todos los clientes con HATEOAS")
    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<ClienteResponseDTO>> obtenerTodos() {
        List<EntityModel<ClienteResponseDTO>> clientes = clienteService.obtenerTodos()
                .stream().map(assembler::toModel).collect(Collectors.toList());
        return CollectionModel.of(clientes,
                linkTo(methodOn(ClienteControllerV2.class).obtenerTodos()).withSelfRel());
    }

    @Operation(summary = "Obtener cliente por ID con HATEOAS")
    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<ClienteResponseDTO>> obtenerPorId(@PathVariable Long id) {
        return clienteService.obtenerPorId(id)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear cliente con HATEOAS")
    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<ClienteResponseDTO>> crear(@Valid @RequestBody ClienteRequestDTO dto) {
        return ResponseEntity.status(201).body(assembler.toModel(clienteService.guardar(dto)));
    }

    @Operation(summary = "Actualizar cliente con HATEOAS")
    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<ClienteResponseDTO>> actualizar(
            @PathVariable Long id, @Valid @RequestBody ClienteRequestDTO dto) {
        return clienteService.actualizar(id, dto)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar cliente con HATEOAS")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (clienteService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        clienteService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}