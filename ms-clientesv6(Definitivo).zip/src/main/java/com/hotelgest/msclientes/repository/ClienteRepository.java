package com.hotelgest.msclientes.repository;

import com.hotelgest.msclientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    @Query("SELECT c FROM Cliente c WHERE c.activo = true")
    List<Cliente> findAllActivos();

    @Query("SELECT c FROM Cliente c WHERE c.hotelId = :hotelId AND c.activo = true")
    List<Cliente> buscarPorHotel(@Param("hotelId") Long hotelId);

    @Query("SELECT c FROM Cliente c WHERE c.usuarioId = :usuarioId AND c.activo = true")
    List<Cliente> buscarPorUsuario(@Param("usuarioId") Long usuarioId);
}