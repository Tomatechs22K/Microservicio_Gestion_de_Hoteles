package com.hotelgest.msclientes;

import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.repository.ClienteRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Random;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        long[] usuarioIds = {1L, 2L, 3L, 4L, 5L};
        long[] hotelIds = {1L, 2L, 3L, 4L, 5L};

        for (int i = 0; i < 10; i++) {
            Cliente cliente = new Cliente();
            cliente.setUsuarioId(usuarioIds[random.nextInt(usuarioIds.length)]);
            cliente.setHotelId(hotelIds[random.nextInt(hotelIds.length)]);

            LocalDate inicio = LocalDate.now().minusDays(faker.number().numberBetween(1, 60));
            LocalDate fin = inicio.plusDays(faker.number().numberBetween(1, 14));

            cliente.setComienzoEstancia(inicio);
            cliente.setFinEstancia(fin);
            cliente.setActivo(true);
            clienteRepository.save(cliente);
        }
    }
}