package com.hotelgest.msclientes.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class ClienteRequestDTO {

    @NotNull(message = "El ID del usuario no puede ser nulo")
    private Long usuarioId;

    @NotNull(message = "El ID del hotel no puede ser nulo")
    private Long hotelId;

    @NotNull(message = "La fecha de comienzo de estancia es obligatoria")
    private LocalDate comienzoEstancia;

    @NotNull(message = "La fecha de fin de estancia es obligatoria")
    private LocalDate finEstancia;
}