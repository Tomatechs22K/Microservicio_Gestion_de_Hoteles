package com.hotelgest.msclientes.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientes")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "usuario_id", nullable = false)
    private Long usuarioId;

    @Column(name = "hotel_id", nullable = false)
    private Long hotelId;

    @Column(name = "comienzo_estancia", nullable = false)
    private LocalDate comienzoEstancia;

    @Column(name = "fin_estancia", nullable = false)
    private LocalDate finEstancia;

    @Column(nullable = false)
    private boolean activo = true;
}