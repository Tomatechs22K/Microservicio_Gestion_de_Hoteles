package com.hotelgest.msclientes.config;

import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final ClienteRepository repository;

    @Override
    public void run(String... args){
        if (repository.count() > 0){
            log.info(">>> CLIENTES YA CARGADOS, SE OMITE INICIALIZACIÓN");
            return;
        }
        log.info(">>> CARGANDO CLIENTES INICIALES");
        repository.save(new Cliente(null, 1L, 1L, LocalDate.of(2026, 1, 10), LocalDate.of(2026, 1, 15), true));
        repository.save(new Cliente(null, 2L, 1L, LocalDate.of(2026, 2, 5), LocalDate.of(2026, 2, 10), true));
        repository.save(new Cliente(null, 3L, 2L, LocalDate.of(2026, 3, 20), LocalDate.of(2026, 3, 25), true));
        log.info(">>> 3 clientes (estancias) cargados...");
    }
}