package com.hotelgest.msclientes.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotelgest.msclientes.dto.ClienteRequestDTO;
import com.hotelgest.msclientes.dto.ClienteResponseDTO;
import com.hotelgest.msclientes.service.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ClienteController.class)
public class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ClienteService clienteService;

    @Autowired
    private ObjectMapper objectMapper;

    private ClienteResponseDTO responseDTO;
    private ClienteRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        responseDTO = new ClienteResponseDTO(1L, 10L, 1L,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 10));
        requestDTO  = new ClienteRequestDTO(10L, 1L,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 10));
    }

    @Test
    public void testObtenerTodos() throws Exception {
        when(clienteService.obtenerTodos()).thenReturn(List.of(responseDTO));

        mockMvc.perform(get("/api/clientes"))
                .andExpect(status().isOk());
    }

    @Test
    public void testObtenerPorId_encontrado() throws Exception {
        when(clienteService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));

        mockMvc.perform(get("/api/clientes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.usuarioId").value(10));
    }

    @Test
    public void testObtenerPorId_noEncontrado() throws Exception {
        when(clienteService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/clientes/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testBuscarPorUsuario() throws Exception {
        when(clienteService.buscarPorUsuario(10L)).thenReturn(List.of(responseDTO));

        mockMvc.perform(get("/api/clientes/usuario/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].usuarioId").value(10));
    }

    @Test
    public void testBuscarPorHotel() throws Exception {
        when(clienteService.buscarPorHotel(1L)).thenReturn(List.of(responseDTO));

        mockMvc.perform(get("/api/clientes/hotel/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].hotelId").value(1));
    }

    @Test
    public void testCrear() throws Exception {
        when(clienteService.guardar(any(ClienteRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/api/clientes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.usuarioId").value(10));
    }

    @Test
    public void testActualizar_encontrado() throws Exception {
        when(clienteService.actualizar(eq(1L), any(ClienteRequestDTO.class)))
                .thenReturn(Optional.of(responseDTO));

        mockMvc.perform(put("/api/clientes/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk());
    }

    @Test
    public void testEliminar_encontrado() throws Exception {
        when(clienteService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));
        doNothing().when(clienteService).eliminar(1L);

        mockMvc.perform(delete("/api/clientes/1"))
                .andExpect(status().isNoContent());

        verify(clienteService, times(1)).eliminar(1L);
    }

    @Test
    public void testEliminar_noEncontrado() throws Exception {
        when(clienteService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/api/clientes/99"))
                .andExpect(status().isNotFound());
    }
}