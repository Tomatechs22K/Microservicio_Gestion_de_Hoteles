package com.hotelgest.msclientes.service;

import com.hotelgest.msclientes.dto.ClienteRequestDTO;
import com.hotelgest.msclientes.dto.ClienteResponseDTO;
import com.hotelgest.msclientes.model.Cliente;
import com.hotelgest.msclientes.repository.ClienteRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class ClienteServiceTest {

    @InjectMocks
    private ClienteService clienteService;

    @Mock
    private ClienteRepository clienteRepository;

    private Cliente crearCliente() {
        return new Cliente(1L, 10L, 1L,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 10), true);
    }

    @Test
    public void testObtenerTodos() {
        when(clienteRepository.findAllActivos()).thenReturn(List.of(crearCliente()));

        List<ClienteResponseDTO> resultado = clienteService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals(10L, resultado.get(0).getUsuarioId());
    }

    @Test
    public void testObtenerPorId_encontrado() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(crearCliente()));

        Optional<ClienteResponseDTO> resultado = clienteService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(1L, resultado.get().getHotelId());
    }

    @Test
    public void testObtenerPorId_noEncontrado() {
        when(clienteRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<ClienteResponseDTO> resultado = clienteService.obtenerPorId(99L);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testObtenerPorId_inactivo() {
        Cliente inactivo = crearCliente();
        inactivo.setActivo(false);
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(inactivo));

        Optional<ClienteResponseDTO> resultado = clienteService.obtenerPorId(1L);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testBuscarPorUsuario() {
        when(clienteRepository.buscarPorUsuario(10L)).thenReturn(List.of(crearCliente()));

        List<ClienteResponseDTO> resultado = clienteService.buscarPorUsuario(10L);

        assertEquals(1, resultado.size());
        assertEquals(10L, resultado.get(0).getUsuarioId());
    }

    @Test
    public void testBuscarPorHotel() {
        when(clienteRepository.buscarPorHotel(1L)).thenReturn(List.of(crearCliente()));

        List<ClienteResponseDTO> resultado = clienteService.buscarPorHotel(1L);

        assertEquals(1, resultado.size());
        assertEquals(1L, resultado.get(0).getHotelId());
    }

    @Test
    public void testGuardar() {
        when(clienteRepository.save(any(Cliente.class))).thenReturn(crearCliente());

        ClienteRequestDTO dto = new ClienteRequestDTO(10L, 1L,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 10));
        ClienteResponseDTO resultado = clienteService.guardar(dto);

        assertNotNull(resultado);
        assertEquals(10L, resultado.getUsuarioId());
    }

    @Test
    public void testActualizar_encontrado() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(crearCliente()));
        when(clienteRepository.save(any(Cliente.class))).thenReturn(crearCliente());

        ClienteRequestDTO dto = new ClienteRequestDTO(10L, 2L,
                LocalDate.of(2026, 7, 1), LocalDate.of(2026, 7, 5));
        Optional<ClienteResponseDTO> resultado = clienteService.actualizar(1L, dto);

        assertTrue(resultado.isPresent());
    }

    @Test
    public void testActualizar_noEncontrado() {
        when(clienteRepository.findById(99L)).thenReturn(Optional.empty());

        ClienteRequestDTO dto = new ClienteRequestDTO(10L, 1L,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 10));
        Optional<ClienteResponseDTO> resultado = clienteService.actualizar(99L, dto);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testEliminar() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(crearCliente()));

        clienteService.eliminar(1L);

        verify(clienteRepository, times(1)).save(any(Cliente.class));
    }
}