package com.hotelgest.mshabitaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MshabitacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MshabitacionesApplication.class, args);
	}

}
