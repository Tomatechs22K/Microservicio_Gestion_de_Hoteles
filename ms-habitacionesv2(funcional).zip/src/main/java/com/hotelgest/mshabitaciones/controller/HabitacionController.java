package com.hotelgest.mshabitaciones.controller;

import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.service.HabitacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/habitaciones")
@RequiredArgsConstructor
public class HabitacionController {

    private final HabitacionService habitacionService;

    @GetMapping
    public ResponseEntity<List<HabitacionResponseDTO>> obtenerTodas() {
        return ResponseEntity.ok(habitacionService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<HabitacionResponseDTO> obtenerPorId(@PathVariable Long id) {
        return habitacionService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<HabitacionResponseDTO>> buscarPorHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(habitacionService.buscarPorHotel(hotelId));
    }

    @PostMapping
    public ResponseEntity<HabitacionResponseDTO> crear(
            @Valid @RequestBody HabitacionRequestDTO dto) {
        return ResponseEntity.status(201).body(habitacionService.guardar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HabitacionResponseDTO> actualizar(
            @PathVariable Long id, @Valid @RequestBody HabitacionRequestDTO dto) {
        return habitacionService.actualizar(id, dto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (habitacionService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        habitacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}