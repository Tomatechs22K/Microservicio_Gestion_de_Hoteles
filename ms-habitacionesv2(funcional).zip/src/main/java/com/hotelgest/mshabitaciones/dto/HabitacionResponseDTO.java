package com.hotelgest.mshabitaciones.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data @NoArgsConstructor @AllArgsConstructor
public class HabitacionResponseDTO {
    private Long id;
    private Long hotelId;
    private String numero;
    private String tipo;
    private BigDecimal precioNoche;
    private boolean disponible;
}