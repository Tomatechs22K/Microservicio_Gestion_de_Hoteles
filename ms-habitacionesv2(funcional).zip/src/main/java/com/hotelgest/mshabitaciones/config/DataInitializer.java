package com.hotelgest.mshabitaciones.config;

import com.hotelgest.mshabitaciones.model.Habitacion;
import com.hotelgest.mshabitaciones.repository.HabitacionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final HabitacionRepository repository;

    @Override
    public void run(String... args){
        if (repository.count() > 0){
            log.info(">>> HABITACIONES YA CARGADAS, SE OMITE INICIALIZACIÓN");
            return;
        }
        log.info(">>> CARGANDO HABITACIONES INICIALES");
        // Habitaciones para el Hotel ID 1
        repository.save(new Habitacion(null, 1L, "101", "Simple", new BigDecimal("50.00"), true, true));
        repository.save(new Habitacion(null, 1L, "102", "Doble", new BigDecimal("85.00"), true, true));
        // Habitaciones para el Hotel ID 2
        repository.save(new Habitacion(null, 2L, "201", "Suite", new BigDecimal("150.00"), true, true));
        repository.save(new Habitacion(null, 2L, "202", "Doble", new BigDecimal("90.00"), true, true));

        log.info(">>> 4 habitaciones cargadas...");
    }
}