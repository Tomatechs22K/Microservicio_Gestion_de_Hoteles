package com.hotelgest.mshabitaciones.controller;

import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.service.HabitacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/habitaciones")
@RequiredArgsConstructor
@Tag(name = "Habitaciones", description = "Operaciones CRUD para la gestión de habitaciones")
public class HabitacionController {

    private final HabitacionService habitacionService;

    @Operation(summary = "Obtener todas las habitaciones activas")
    @ApiResponse(responseCode = "200", description = "Lista retornada exitosamente")
    @GetMapping
    public ResponseEntity<CollectionModel<HabitacionResponseDTO>> obtenerTodas() {
        List<HabitacionResponseDTO> habitaciones = habitacionService.obtenerTodas();
        habitaciones.forEach(h -> h.add(
                linkTo(methodOn(HabitacionController.class).obtenerPorId(h.getId())).withSelfRel(),
                linkTo(methodOn(HabitacionController.class).buscarPorHotel(h.getHotelId())).withRel("hotel")
        ));
        return ResponseEntity.ok(CollectionModel.of(habitaciones,
                linkTo(methodOn(HabitacionController.class).obtenerTodas()).withSelfRel()));
    }

    @Operation(summary = "Obtener habitación por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Habitación encontrada"),
            @ApiResponse(responseCode = "404", description = "Habitación no encontrada")
    })
    @GetMapping("/{id}")
    public ResponseEntity<HabitacionResponseDTO> obtenerPorId(@PathVariable Long id) {
        return habitacionService.obtenerPorId(id)
                .map(h -> {
                    h.add(
                            linkTo(methodOn(HabitacionController.class).obtenerPorId(id)).withSelfRel(),
                            linkTo(methodOn(HabitacionController.class).obtenerTodas()).withRel("todas"),
                            linkTo(methodOn(HabitacionController.class).buscarPorHotel(h.getHotelId())).withRel("hotel")
                    );
                    return ResponseEntity.ok(h);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Obtener habitaciones por hotel")
    @ApiResponse(responseCode = "200", description = "Lista retornada exitosamente")
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<HabitacionResponseDTO>> buscarPorHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(habitacionService.buscarPorHotel(hotelId));
    }

    @Operation(summary = "Crear una nueva habitación")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Habitación creada exitosamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<HabitacionResponseDTO> crear(@Valid @RequestBody HabitacionRequestDTO dto) {
        HabitacionResponseDTO creada = habitacionService.guardar(dto);
        creada.add(linkTo(methodOn(HabitacionController.class).obtenerPorId(creada.getId())).withSelfRel());
        return ResponseEntity.status(201).body(creada);
    }

    @Operation(summary = "Actualizar una habitación existente")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Habitación actualizada exitosamente"),
            @ApiResponse(responseCode = "404", description = "Habitación no encontrada")
    })
    @PutMapping("/{id}")
    public ResponseEntity<HabitacionResponseDTO> actualizar(
            @PathVariable Long id, @Valid @RequestBody HabitacionRequestDTO dto) {
        return habitacionService.actualizar(id, dto)
                .map(h -> {
                    h.add(linkTo(methodOn(HabitacionController.class).obtenerPorId(id)).withSelfRel());
                    return ResponseEntity.ok(h);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar (soft delete) una habitación")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Habitación eliminada exitosamente"),
            @ApiResponse(responseCode = "404", description = "Habitación no encontrada")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (habitacionService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        habitacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}