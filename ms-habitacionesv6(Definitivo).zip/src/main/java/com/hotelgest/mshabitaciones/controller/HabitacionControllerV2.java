package com.hotelgest.mshabitaciones.controller;

import com.hotelgest.mshabitaciones.assemblers.HabitacionModelAssembler;
import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.service.HabitacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/habitaciones")
@RequiredArgsConstructor
@Tag(name = "Habitaciones V2", description = "Operaciones CRUD con HATEOAS")
public class HabitacionControllerV2 {

    private final HabitacionService habitacionService;
    private final HabitacionModelAssembler assembler;

    @Operation(summary = "Obtener todas las habitaciones con HATEOAS")
    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<HabitacionResponseDTO>> obtenerTodas() {
        List<EntityModel<HabitacionResponseDTO>> habitaciones = habitacionService.obtenerTodas()
                .stream().map(assembler::toModel).collect(Collectors.toList());
        return CollectionModel.of(habitaciones,
                linkTo(methodOn(HabitacionControllerV2.class).obtenerTodas()).withSelfRel());
    }

    @Operation(summary = "Obtener habitación por ID con HATEOAS")
    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HabitacionResponseDTO>> obtenerPorId(@PathVariable Long id) {
        return habitacionService.obtenerPorId(id)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear habitación con HATEOAS")
    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HabitacionResponseDTO>> crear(@Valid @RequestBody HabitacionRequestDTO dto) {
        return ResponseEntity.status(201).body(assembler.toModel(habitacionService.guardar(dto)));
    }

    @Operation(summary = "Actualizar habitación con HATEOAS")
    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<HabitacionResponseDTO>> actualizar(
            @PathVariable Long id, @Valid @RequestBody HabitacionRequestDTO dto) {
        return habitacionService.actualizar(id, dto)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar habitación con HATEOAS")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (habitacionService.obtenerPorId(id).isEmpty())
            return ResponseEntity.notFound().build();
        habitacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}