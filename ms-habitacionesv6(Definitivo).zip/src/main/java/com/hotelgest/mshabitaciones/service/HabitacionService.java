package com.hotelgest.mshabitaciones.service;

import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.model.Habitacion;
import com.hotelgest.mshabitaciones.repository.HabitacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HabitacionService {

    private final HabitacionRepository habitacionRepository;

    private HabitacionResponseDTO mapToDTO(Habitacion h) {
        return new HabitacionResponseDTO(h.getId(), h.getHotelId(),
                h.getNumero(), h.getTipo(), h.getPrecioNoche(), h.isDisponible());
    }

    public List<HabitacionResponseDTO> obtenerTodas() {
        return habitacionRepository.findAllActivas().stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<HabitacionResponseDTO> obtenerPorId(Long id) {
        return habitacionRepository.findById(id)
                .filter(Habitacion::isActivo)
                .map(this::mapToDTO);
    }

    public List<HabitacionResponseDTO> buscarPorHotel(Long hotelId) {
        return habitacionRepository.buscarPorHotel(hotelId).stream()
                .map(this::mapToDTO).collect(Collectors.toList());
    }

    public HabitacionResponseDTO guardar(HabitacionRequestDTO dto) {
        Habitacion habitacion = new Habitacion(null, dto.getHotelId(), dto.getNumero(),
                dto.getTipo(), dto.getPrecioNoche(), true, true);
        return mapToDTO(habitacionRepository.save(habitacion));
    }

    public Optional<HabitacionResponseDTO> actualizar(Long id, HabitacionRequestDTO dto) {
        return habitacionRepository.findById(id).map(existente -> {
            existente.setHotelId(dto.getHotelId());
            existente.setNumero(dto.getNumero());
            existente.setTipo(dto.getTipo());
            existente.setPrecioNoche(dto.getPrecioNoche());
            return mapToDTO(habitacionRepository.save(existente));
        });
    }

    public void eliminar(Long id) {
        habitacionRepository.findById(id).ifPresent(existente -> {
            existente.setActivo(false);
            habitacionRepository.save(existente);
        });
    }
}