package com.hotelgest.mshabitaciones.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class HabitacionResponseDTO extends RepresentationModel<HabitacionResponseDTO> {
    private Long id;
    private Long hotelId;
    private String numero;
    private String tipo;
    private BigDecimal precioNoche;
    private boolean disponible;
}