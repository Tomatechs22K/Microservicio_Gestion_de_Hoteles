package com.hotelgest.mshabitaciones.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data @NoArgsConstructor @AllArgsConstructor
public class HabitacionRequestDTO {

    @NotNull(message = "El ID del hotel es obligatorio")
    private Long hotelId;

    @NotBlank(message = "El número de habitación no puede estar vacío")
    @Size(max = 10, message = "Máximo 10 caracteres")
    private String numero;

    @NotBlank(message = "El tipo de habitación no puede estar vacío")
    @Size(max = 50, message = "Máximo 50 caracteres")
    private String tipo;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor a 0")
    private BigDecimal precioNoche;
}