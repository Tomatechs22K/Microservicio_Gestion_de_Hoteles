package com.hotelgest.mshabitaciones.assemblers;

import com.hotelgest.mshabitaciones.controller.HabitacionController;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class HabitacionModelAssembler implements RepresentationModelAssembler<HabitacionResponseDTO, EntityModel<HabitacionResponseDTO>> {

    @Override
    public EntityModel<HabitacionResponseDTO> toModel(HabitacionResponseDTO habitacion) {
        return EntityModel.of(habitacion,
                linkTo(methodOn(HabitacionController.class).obtenerPorId(habitacion.getId())).withSelfRel(),
                linkTo(methodOn(HabitacionController.class).obtenerTodas()).withRel("habitaciones"),
                linkTo(methodOn(HabitacionController.class).buscarPorHotel(habitacion.getHotelId())).withRel("hotel")
        );
    }
}