package com.hotelgest.mshabitaciones;

import com.hotelgest.mshabitaciones.model.Habitacion;
import com.hotelgest.mshabitaciones.repository.HabitacionRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Random;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private HabitacionRepository habitacionRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        String[] tipos = {"Simple", "Doble", "Suite", "Familiar", "Deluxe"};
        long[] hotelIds = {1L, 2L, 3L, 4L, 5L};

        for (int i = 0; i < 20; i++) {
            Habitacion habitacion = new Habitacion();
            habitacion.setHotelId(hotelIds[random.nextInt(hotelIds.length)]);
            habitacion.setNumero(String.valueOf(faker.number().numberBetween(100, 999)));
            habitacion.setTipo(tipos[random.nextInt(tipos.length)]);
            habitacion.setPrecioNoche(BigDecimal.valueOf(faker.number().numberBetween(30, 500)));
            habitacion.setDisponible(faker.bool().bool());
            habitacion.setActivo(true);
            habitacionRepository.save(habitacion);
        }
    }
}