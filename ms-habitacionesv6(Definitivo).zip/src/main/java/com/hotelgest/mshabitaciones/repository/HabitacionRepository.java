package com.hotelgest.mshabitaciones.repository;

import com.hotelgest.mshabitaciones.model.Habitacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface HabitacionRepository extends JpaRepository<Habitacion, Long> {

    @Query("SELECT h FROM Habitacion h WHERE h.activo = true")
    List<Habitacion> findAllActivas();

    @Query("SELECT h FROM Habitacion h WHERE h.hotelId = :hotelId AND h.activo = true")
    List<Habitacion> buscarPorHotel(@Param("hotelId") Long hotelId);
}