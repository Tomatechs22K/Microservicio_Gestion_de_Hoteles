package com.hotelgest.mshabitaciones.service;

import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.model.Habitacion;
import com.hotelgest.mshabitaciones.repository.HabitacionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class HabitacionServiceTest {

    @InjectMocks
    private HabitacionService habitacionService;

    @Mock
    private HabitacionRepository habitacionRepository;

    private Habitacion crearHabitacion() {
        return new Habitacion(1L, 1L, "101", "Suite",
                BigDecimal.valueOf(150.00), true, true);
    }

    @Test
    public void testObtenerTodas() {
        when(habitacionRepository.findAllActivas()).thenReturn(List.of(crearHabitacion()));

        List<HabitacionResponseDTO> resultado = habitacionService.obtenerTodas();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("101", resultado.get(0).getNumero());
    }

    @Test
    public void testObtenerPorId_encontrado() {
        when(habitacionRepository.findById(1L)).thenReturn(Optional.of(crearHabitacion()));

        Optional<HabitacionResponseDTO> resultado = habitacionService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Suite", resultado.get().getTipo());
    }

    @Test
    public void testObtenerPorId_noEncontrado() {
        when(habitacionRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<HabitacionResponseDTO> resultado = habitacionService.obtenerPorId(99L);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testGuardar() {
        when(habitacionRepository.save(any(Habitacion.class))).thenReturn(crearHabitacion());

        HabitacionRequestDTO dto = new HabitacionRequestDTO(1L, "101", "Suite", BigDecimal.valueOf(150.00));
        HabitacionResponseDTO resultado = habitacionService.guardar(dto);

        assertNotNull(resultado);
        assertEquals("Suite", resultado.getTipo());
        assertEquals(BigDecimal.valueOf(150.00), resultado.getPrecioNoche());
    }

    @Test
    public void testActualizar_encontrado() {
        when(habitacionRepository.findById(1L)).thenReturn(Optional.of(crearHabitacion()));
        when(habitacionRepository.save(any(Habitacion.class))).thenReturn(crearHabitacion());

        HabitacionRequestDTO dto = new HabitacionRequestDTO(1L, "102", "Doble", BigDecimal.valueOf(90.00));
        Optional<HabitacionResponseDTO> resultado = habitacionService.actualizar(1L, dto);

        assertTrue(resultado.isPresent());
    }

    @Test
    public void testActualizar_noEncontrado() {
        when(habitacionRepository.findById(99L)).thenReturn(Optional.empty());

        HabitacionRequestDTO dto = new HabitacionRequestDTO(1L, "102", "Doble", BigDecimal.valueOf(90.00));
        Optional<HabitacionResponseDTO> resultado = habitacionService.actualizar(99L, dto);

        assertFalse(resultado.isPresent());
    }

    @Test
    public void testEliminar() {
        when(habitacionRepository.findById(1L)).thenReturn(Optional.of(crearHabitacion()));

        habitacionService.eliminar(1L);

        verify(habitacionRepository, times(1)).save(any(Habitacion.class));
    }
}