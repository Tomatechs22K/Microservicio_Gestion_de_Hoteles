package com.hotelgest.mshabitaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MshabitacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
