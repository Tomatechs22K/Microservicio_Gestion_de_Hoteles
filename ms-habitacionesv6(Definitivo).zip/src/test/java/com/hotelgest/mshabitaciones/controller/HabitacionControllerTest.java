package com.hotelgest.mshabitaciones.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotelgest.mshabitaciones.dto.HabitacionRequestDTO;
import com.hotelgest.mshabitaciones.dto.HabitacionResponseDTO;
import com.hotelgest.mshabitaciones.service.HabitacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(HabitacionController.class)
public class HabitacionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private HabitacionService habitacionService;

    @Autowired
    private ObjectMapper objectMapper;

    private HabitacionResponseDTO responseDTO;
    private HabitacionRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        responseDTO = new HabitacionResponseDTO(1L, 1L, "101", "Suite", BigDecimal.valueOf(150.00), true);
        requestDTO  = new HabitacionRequestDTO(1L, "101", "Suite", BigDecimal.valueOf(150.00));
    }

    @Test
    public void testObtenerTodas() throws Exception {
        when(habitacionService.obtenerTodas()).thenReturn(List.of(responseDTO));

        mockMvc.perform(get("/api/habitaciones"))
                .andExpect(status().isOk());
    }

    @Test
    public void testObtenerPorId_encontrado() throws Exception {
        when(habitacionService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));

        mockMvc.perform(get("/api/habitaciones/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipo").value("Suite"));
    }

    @Test
    public void testObtenerPorId_noEncontrado() throws Exception {
        when(habitacionService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/habitaciones/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testCrear() throws Exception {
        when(habitacionService.guardar(any(HabitacionRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/api/habitaciones")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.numero").value("101"));
    }

    @Test
    public void testActualizar_encontrado() throws Exception {
        when(habitacionService.actualizar(eq(1L), any(HabitacionRequestDTO.class)))
                .thenReturn(Optional.of(responseDTO));

        mockMvc.perform(put("/api/habitaciones/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipo").value("Suite"));
    }

    @Test
    public void testEliminar_encontrado() throws Exception {
        when(habitacionService.obtenerPorId(1L)).thenReturn(Optional.of(responseDTO));
        doNothing().when(habitacionService).eliminar(1L);

        mockMvc.perform(delete("/api/habitaciones/1"))
                .andExpect(status().isNoContent());

        verify(habitacionService, times(1)).eliminar(1L);
    }

    @Test
    public void testEliminar_noEncontrado() throws Exception {
        when(habitacionService.obtenerPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/api/habitaciones/99"))
                .andExpect(status().isNotFound());
    }
}