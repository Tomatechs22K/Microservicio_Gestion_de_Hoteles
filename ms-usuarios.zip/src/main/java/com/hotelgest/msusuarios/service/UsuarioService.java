package com.hotelgest.msusuarios.service;

import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// @RequiredArgsConstructor → inyección por constructor de todos los final.
// @Service     → marca esta clase como componente de capa de negocio.
@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public List<Usuario> obtenerTodas() {
        return usuarioRepository.findAll();
    }

    public List<Usuario> buscarPorNombre(String nombre) {
        return usuarioRepository.buscarPorNombre(nombre);
    }

    public List<Usuario> buscarPorRol(String rol) {
        return usuarioRepository.buscarPorRol(rol);
    }

    public Optional<Usuario> obtenerPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    public Usuario guardar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Optional<Usuario> actualizar(Long id, Usuario datos) {
        return usuarioRepository.findById(id).map(e -> {
            e.setNombre(datos.getNombre());
            e.setRol(datos.getRol());
            e.setTelefono(datos.getTelefono());
            return usuarioRepository.save(e);
        });
    }

    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }
}
