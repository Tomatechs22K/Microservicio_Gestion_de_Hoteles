package com.hotelgest.msusuarios.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// ═══════════════════════════════════════════════════
// @Entity  → Hibernate registra esta clase como entidad JPA.
//            Crea/actualiza la tabla 'hoteles' al arrancar.
// @Table   → nombre explícito de la tabla en MySQL.
// @Data    → Lombok genera getters, setters, equals, toString.
// ═══════════════════════════════════════════════════
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "usuarios")
public class Usuario {

    // @Id + IDENTITY → clave primaria AUTO_INCREMENT en MySQL
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre no puede estar vacío")
    @Size(max = 100, message = "Máximo 100 caracteres")
    @Column(nullable = false, unique = true, length = 100)
    private String nombre;

    @NotBlank(message = "El rol no puede estar vacío")
    @Size(max = 100)
    @Column(length = 100)
    private String rol;

    @NotBlank(message = "El telefono no puede estar vacío")
    @Size(max = 20)
    @Column(nullable = false, length = 20)
    private String telefono;
}