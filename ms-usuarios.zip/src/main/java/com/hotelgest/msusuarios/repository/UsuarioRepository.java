package com.hotelgest.msusuarios.repository;

import com.hotelgest.msusuarios.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

// ═══════════════════════════════════════════════════
// JpaRepository<Hotel, Long> nos da gratis:
//   findAll(), findById(), save(), deleteById(), count()…
//
// @Query usa JPQL: se escribe sobre CLASES y ATRIBUTOS Java,
// NO sobre tablas y columnas SQL.
// ═══════════════════════════════════════════════════
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // LOWER() en ambos lados → búsqueda case-insensitive
    // CONCAT('%', :nombre, '%') → patrón LIKE dinámico
    @Query("SELECT e FROM Usuarios e WHERE LOWER(e.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    List<Usuario> buscarPorNombre(@Param("nombre") String nombre);

    @Query("SELECT e FROM Usuarios e WHERE LOWER(e.rol) LIKE LOWER(CONCAT('%', :rol, '%'))")
    List<Usuario> buscarPorRol(@Param("rol") String rol);
}
