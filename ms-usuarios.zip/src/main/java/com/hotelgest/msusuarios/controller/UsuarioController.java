package com.hotelgest.msusuarios.controller;

import com.hotelgest.msusuarios.model.Usuario;
import com.hotelgest.msusuarios.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// @RestController = @Controller + @ResponseBody
// @RequestMapping → prefijo base para todos los endpoints
@RestController
@RequestMapping("/api/hoteles")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    // GET /api/hoteles → todas
    @GetMapping
    public List<Usuario> obtenerTodas() {
        return usuarioService.obtenerTodas();
    }


    // GET /api/hoteles/buscar?nombre=cir → búsqueda parcial
    @GetMapping("/buscar")
    public List<Usuario> buscar(@RequestParam String nombre) {
        return usuarioService.buscarPorNombre(nombre);
    }

    @GetMapping("/roles")
    public List<Usuario> buscarRol(@RequestParam String rol) {
        return usuarioService.buscarPorRol(rol);
    }

    // GET /api/hoteles/{id}
    // ResponseEntity permite devolver 200 con body o 404 vacío
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> obtenerPorId(@PathVariable Long id) {
        return usuarioService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /api/hoteles → @Valid activa las validaciones del modelo
    @PostMapping
    public ResponseEntity<Usuario> crear(@Valid @RequestBody Usuario usuario) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(usuarioService.guardar(usuario));
    }

    // PUT /api/hoteles/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody Usuario datos) {
        return usuarioService.actualizar(id, datos)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE /api/hoteles/{id} → 204 No Content
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        usuarioService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
