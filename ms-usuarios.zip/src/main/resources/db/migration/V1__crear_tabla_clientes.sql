CREATE TABLE clientes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    rol VARCHAR(100),
    telefono VARCHAR(20),
);

-- Insertar datos iniciales para probar
INSERT INTO clientes (nombre, rol, telefono)
VALUES ('Test', 'Visitador', "56 9 000 000");